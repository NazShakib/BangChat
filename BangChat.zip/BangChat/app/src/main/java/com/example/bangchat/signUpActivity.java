package com.example.bangchat;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class signUpActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
    }

    public void sigupAccount(View view) {
    }
}
